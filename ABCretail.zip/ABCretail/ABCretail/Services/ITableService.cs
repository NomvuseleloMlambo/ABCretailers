﻿using ABCretail.Models;
using System.Collections.Generic;
using System.Threading.Tasks;

namespace ABCretail.Services
{
    public interface ITableService
    {
        Task AddCustomerAsync(CustomerEntity customer);
        Task<List<CustomerEntity>> GetCustomersAsync(string tableName);
    }
}


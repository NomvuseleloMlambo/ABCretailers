﻿using System.Threading.Tasks;

namespace ABCretail.Services
{
    public interface IQueueService
    {
        Task SendMessageAsync(string queueName, string message);
    }
}


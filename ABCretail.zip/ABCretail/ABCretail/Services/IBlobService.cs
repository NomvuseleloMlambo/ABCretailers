﻿using ABCretail.Services;


namespace ABCretail.Services
{
    public class IBlobService
    {
    }
}

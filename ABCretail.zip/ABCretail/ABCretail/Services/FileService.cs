﻿using Azure.Storage.Files.Shares;
using System.IO;
using System.Threading.Tasks;

namespace ABCretail.Services
{
    public class FileService : IFileService
    {
        private readonly ShareClient _shareClient;

        public FileService(ShareClient shareClient)
        {
            _shareClient = shareClient;
        }

        public async Task UploadFileAsync(string directoryName, string fileName, Stream fileStream)
        {
            var directoryClient = _shareClient.GetDirectoryClient(directoryName);
            var fileClient = directoryClient.GetFileClient(fileName);
            await fileClient.CreateAsync(fileStream.Length);
            await fileClient.UploadAsync(fileStream);
        }
    }
}

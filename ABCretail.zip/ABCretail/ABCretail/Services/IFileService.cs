﻿using Microsoft.AspNetCore.Http;
using System.Threading.Tasks;

namespace ABCretail.Services
{
    public interface IFileService
    {
        Task UploadContractAsync(string directoryName, string fileName, IFormFile file);
    }
}

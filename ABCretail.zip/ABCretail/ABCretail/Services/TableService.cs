﻿using Azure.Data.Tables;
using System.Threading.Tasks;
using ABCretail.Models;

namespace ABCretail.Services
{
    public class TableService : ITableService
    {
        private readonly TableClient _tableClient;

        public TableService(TableClient tableClient)
        {
            _tableClient = tableClient;
        }

        public async Task AddCustomerAsync(CustomerEntity customer)
        {
            TableEntity entity = new TableEntity(customer.Id, customer.Name)
            {
                { "Email", customer.Email },
                { "PhoneNumber", customer.PhoneNumber }
            };
            await _tableClient.AddEntityAsync(entity);
        }
    }
}

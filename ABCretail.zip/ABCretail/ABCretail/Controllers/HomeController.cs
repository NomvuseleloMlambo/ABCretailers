using Microsoft.AspNetCore.Mvc;
using ABCretail.Services;
using ABCretail.Models;
using System.Threading.Tasks;

namespace ABCretail.Controllers
{
    public class HomeController : Controller
    {
        private readonly ITableService _tableService;
        private readonly IBlobService _blobService;
        private readonly IQueueService _queueService;
        private readonly IFileService _fileService;

        public HomeController(ITableService tableService, IBlobService blobService, IQueueService queueService, IFileService fileService)
        {
            _tableService = tableService;
            _blobService = blobService;
            _queueService = queueService;
            _fileService = fileService;
        }

        public IActionResult Index()
        {
            return View();
        }

        [HttpPost]
        public async Task<IActionResult> AddCustomer(CustomerEntity customer)
        {
            await _tableService.AddCustomerAsync(customer);
            return RedirectToAction("Index");
        }

        [HttpPost]
        public async Task<IActionResult> UploadImage(IFormFile image)
        {
            using (var stream = image.OpenReadStream())
            {
                await _blobService.UploadBlobAsync("customer-images", image.FileName, stream);
            }
            return RedirectToAction("Index");
        }

        [HttpPost]
        public async Task<IActionResult> SendMessage(string message)
        {
            await _queueService.SendMessageAsync(message);
            return RedirectToAction("Index");
        }

        [HttpPost]
        public async Task<IActionResult> UploadContract(IFormFile contract)
        {
            using (var stream = contract.OpenReadStream())
            {
                await _fileService.UploadFileAsync("contracts", contract.FileName, stream);
            }
            return RedirectToAction("Index");
        }
    }
}



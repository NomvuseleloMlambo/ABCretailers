﻿using Microsoft.Azure.WebJobs;
using Microsoft.Extensions.Logging;
using Microsoft.Azure.WebJobs.Extensions.Http;
using System.Threading.Tasks;
using ABCretail.Services;

namespace ABCretail.Functions
{
    public class SendMessageFunction
    {
        private readonly IQueueService _queueService;

        public SendMessageFunction(IQueueService queueService)
        {
            _queueService = queueService;
        }

        [FunctionName("SendMessageFunction")]
        public async Task Run(
            [HttpTrigger(AuthorizationLevel.Function, "post", Route = null)] HttpRequest req,
            ILogger log)
        {
            // Logic to send a message to the queue
            await _queueService.SendMessageAsync("Your message here");
        }
    }
}

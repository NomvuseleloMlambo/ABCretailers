﻿using Microsoft.Azure.WebJobs;
using Microsoft.Extensions.Logging;
using Microsoft.AspNetCore.Http;
using Microsoft.Azure.WebJobs.Extensions.Http;
using System.Threading.Tasks;
using ABCretail.Services;
using Microsoft.AspNetCore.Mvc;

namespace ABCretail.Functions
{
    public class UploadContractFunction
    {
        private readonly IFileService _fileService;

        public UploadContractFunction(IFileService fileService)
        {
            _fileService = fileService;
        }

        [FunctionName("UploadContractFunction")]
        public async Task<IActionResult> Run(
            [HttpTrigger(AuthorizationLevel.Function, "post", Route = null)] HttpRequest req,
            ILogger log)
        {
            // Logic to upload the contract
            return new OkResult();
        }
    }
}


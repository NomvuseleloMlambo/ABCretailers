﻿using Microsoft.Azure.WebJobs;
using Microsoft.Extensions.Logging;
using Microsoft.AspNetCore.Http;
using System.Threading.Tasks;
using ABCretail.Services;

namespace ABCretail.Functions
{
    public class AddCustomerFunction
    {
        private readonly ITableService _tableService;

        public AddCustomerFunction(ITableService tableService)
        {
            _tableService = tableService;
        }

        [FunctionName("AddCustomer")]
        public async Task Run([HttpTrigger(AuthorizationLevel.Function, "post", Route = null)] HttpRequest req, ILogger log)
        {
            // Implementation to read request and add customer
        }
    }
}

